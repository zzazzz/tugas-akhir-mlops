
import tensorflow as tf
import tensorflow_transform as tft
from tfx.components.trainer.fn_args_utils import FnArgs
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib
import os
import numpy as np

# Definisikan nama label
LABEL_KEY = "target"

# Daftar fitur numerik dan kategorikal
NUMERIC_FEATURES = ['age', 'ca', 'chol', 'oldpeak', 'thalach', 'trestbps']
CATEGORICAL_FEATURES = ['cp', 'exang', 'fbs', 'restecg', 'sex', 'slope', 'thal']

def transformed_name(key):
    """Menambahkan suffix '_xf' pada nama fitur yang telah ditransformasi"""
    return key + "_xf"

# Fungsi untuk membaca data yang telah di-compress
def gzip_reader_fn(filenames):
    return tf.data.TFRecordDataset(filenames, compression_type='GZIP')

# Fungsi input untuk mempersiapkan dataset
def input_fn(file_pattern, tf_transform_output, num_epochs, batch_size=64):
    # Mendapatkan feature_spec untuk fitur yang sudah ditransformasi
    transform_feature_spec = tf_transform_output.transformed_feature_spec().copy()

    # Membaca data dalam bentuk batch
    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transform_feature_spec,
        reader=gzip_reader_fn,
        num_epochs=num_epochs,
        label_key='target'  # Menggunakan 'target' sebagai label key yang benar
    )

    # Fungsi untuk format data (menyesuaikan label dan fitur)
    def format_data(features, labels):
        labels = tf.reshape(labels, [-1, 1])  # Bentuk label sesuai dengan output
        return features, labels

    return dataset.map(format_data)

# Fungsi utama untuk menjalankan pelatihan
def run_fn(fn_args: FnArgs):
    # Menginisialisasi tf_transform_output
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_output)

    # Membaca dataset pelatihan dan evaluasi
    train_dataset = input_fn(fn_args.train_files, tf_transform_output, num_epochs=1)
    eval_dataset = input_fn(fn_args.eval_files, tf_transform_output, num_epochs=1)

    # Konversi dataset ke numpy untuk digunakan oleh Random Forest
    def dataset_to_numpy(dataset):
        features, labels = [], []
        for batch_features, batch_labels in dataset:
            features.append(batch_features)
            labels.append(batch_labels)
        
        features = {key: np.concatenate([f[key] for f in features], axis=0) for key in features[0].keys()}
        labels = np.concatenate(labels, axis=0)

        return features, labels

    train_features, train_labels = dataset_to_numpy(train_dataset)
    eval_features, eval_labels = dataset_to_numpy(eval_dataset)

    # Preprocessing: Menggabungkan fitur menjadi satu array untuk model Random Forest
    def preprocess_features(features):
        return np.column_stack([features[transformed_name(f)] for f in NUMERIC_FEATURES + CATEGORICAL_FEATURES])

    train_x = preprocess_features(train_features)
    train_y = train_labels.ravel()
    eval_x = preprocess_features(eval_features)
    eval_y = eval_labels.ravel()

    # Membuat dan melatih model Random Forest
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(train_x, train_y)

    # Evaluasi model
    eval_predictions = model.predict(eval_x)
    eval_accuracy = accuracy_score(eval_y, eval_predictions)
    print(f"Evaluation Accuracy: {eval_accuracy}")

    # Menyimpan model yang telah dilatih
    model_dir = fn_args.serving_model_dir
    os.makedirs(model_dir, exist_ok=True)
    joblib.dump(model, os.path.join(model_dir, 'model.joblib'))

    print("Model has been saved successfully.")
